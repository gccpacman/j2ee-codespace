
1. Database Preparation - 

Run SQL File on MySQL Database through command prompt or using IDE like SQLyog or PhpMyAdmin.

2. How to import project into eclipse

a.first click on File --> New --> Java Project.
b.then remove check for Use Default location and give proper project location.
c.finally click on finish to import.
d.after importing project we have to configure >>the build path<< and add required external jar files from 'lib' folder to run a project.

