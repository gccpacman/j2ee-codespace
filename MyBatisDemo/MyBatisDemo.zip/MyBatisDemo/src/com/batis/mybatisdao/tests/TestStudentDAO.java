package com.batis.mybatisdao.tests;

import java.io.Reader;
import java.util.ArrayList;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;

import com.batis.mybatisdao.tests.dao.StudentDAO;
import com.batis.mybatisdao.tests.model.Student;

public class TestStudentDAO {

    private static Logger log = Logger.getLogger(TestStudentDAO.class);
    private static SqlSessionFactory sf;
    private static StudentDAO studentDao;

    @BeforeClass
    public static void setUp() throws Exception {

	log.info(" Mybatis setup is in progress...");
	String resource = "mybatisConfig.xml";
	Reader reader = Resources.getResourceAsReader(resource);
	sf = new SqlSessionFactoryBuilder().build(reader, "mobisoft");
	studentDao = new StudentDAO(sf);
	log.info(" Connection Established Successfully.");
    }

    @Test
    public static void getAllStudents() {

	ArrayList<Student> list = studentDao.getAllStudentList();
	log.info("Student List: ");
	printStudentList(list);

    }

    public static void createStudent() {

	Student student = new Student();
	student.setStudentName("Mayur");
	student.setMarks(82);
	Integer rollNo = studentDao.insertStudent(student);
	log.info("insert Student Details: " + rollNo);

    }

    public static void updateStudent() {

	Student student = new Student();
	student.setRollNo(1);
	Integer result = studentDao.updateStudentDetails(student);
	log.info("update Student Details: " + result);
    }

    public static void deleteStudent() {

	Integer rollNo = studentDao.deleteStudentFromDB(3);
	log.info("delete Student's rollNo: " + rollNo);

    }

    private static void printStudentList(ArrayList<?> studentList) {
	for (int i = 0; i < studentList.size(); i++) {
	    log.info(studentList.get(i).toString());
	}
    }

    public static void main(String arg[]) {
	try {
	    setUp();
	    // updateStudent();
	    // createStudent();
	    // deleteStudent();
	    getAllStudents();
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

}
