package com.batis.mybatisdao.tests.dao;

import org.apache.ibatis.session.SqlSessionFactory;

import com.batis.mybatisdao.JdbcBaseBatisDAO;
import com.batis.mybatisdao.tests.model.Student;

public class StudentDAO extends JdbcBaseBatisDAO<Student, Integer> {

    public StudentDAO(SqlSessionFactory containerSessionFactory) {
	super(containerSessionFactory);
    }
}
