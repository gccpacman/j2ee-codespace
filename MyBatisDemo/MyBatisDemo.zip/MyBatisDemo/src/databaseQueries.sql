CREATE DATABASE IF NOT EXISTS studentdb;

USE studentdb;

/*Table structure for table Student */

DROP TABLE IF EXISTS Student;

CREATE TABLE Student (
rollNo INT(11) NOT NULL AUTO_INCREMENT,
studentName VARCHAR(30) DEFAULT NULL,
marks INT(11) DEFAULT NULL,
PRIMARY KEY (rollNo)
);

/*insert data into table Student */

INSERT INTO Student(rollNo,studentName,marks) VALUES (1,'John P',82),(2,'Abdul K',94),(3,'Raju S',35);